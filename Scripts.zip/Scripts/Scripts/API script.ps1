$i = 0
do {
$region = Read-Host "Enter the region:"
$packageName = Read-Host "Enter the package name:"

# List the versions of the package
$versionsOutput = aws ssm list-document-versions --name "$packageName" --region $region | ConvertFrom-Json

$versions = $versionsOutput.DocumentVersions
$versionCount = $versions.Count

Write-Host "Number of package versions available: $versionCount"

if ($versionCount -gt 22) {
    $versionsToDelete = ($versions | Select-Object -Last ($versionCount - 22) | Where-Object { $_.IsDefaultVersion -eq $false }).DocumentVersion

    $deleteCount = 0
    foreach ($version in $versionsToDelete) {
        $deleteCommand = "aws ssm delete-document --name ""$packageName"" --document-version ""$version"" --region $region"
        try {
            Invoke-Expression $deleteCommand
            $deleteCount++
            Write-Host "Deleted package version: $version"
        } catch {
            Write-Host "An error occurred when deleting package version: $version"
            Write-Host $_.Exception.Message
        }
    }

    Write-Host "Number of package versions deleted: $deleteCount"
}
else {
    Write-Host "No versions to delete."
}
$i = Read-Host "Enter 1 exist :"
} while ($i -ne 1)