﻿#adding path python & pip executable 
$env:Path += ';$HOME\AppData\Local\Programs\Python\Python310'
$env:Path += ';$HOME\AppData\Local\Programs\Python\Python310\Scripts'
$env:Path += ';C:\ProgramData\Git'

python.exe -m pip install --upgrade pip


#pip.exe install awscli
#pip.exe install azure-cli
#pip.exe install git-bash
pip.exe install awsprocesscreds
pip.exe install git-remote-codecommit
pip.exe install boto3
pip.exe install pycryptodome

C:\Users\Your Name\AppData\Local\Programs\Python\Python36-32\Scripts>pip --version