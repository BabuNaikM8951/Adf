﻿#adding path python AND pip executable 

#set PATH=%PATH%;C:\Users\hp\AppData\Local\Programs\Python\Python310\
#set PATH=%PATH%;C:\Users\hp\AppData\Local\Programs\Python\Python31pip

$env:Path += ';C:\Users\Administrator\AppData\Local\Programs\Python\Python310'
$env:Path += ';C:\Users\Administrator\AppData\Local\Programs\Python\Python310\Scripts'
$env:Path += ';C:\ProgramData\Microsoft\Windows\Start Menu\Programs\Git'

#https://github.com/git-for-windows/git/releases/download/v2.37.2.windows.2/Git-2.37.2.2-64-bit.exe



#cd $path 

#C:\Users\Administrator\AppData\Local\Programs\Python\Python310\Scripts\pip.exe install awscli
#C:\Users\Administrator\AppData\Local\Programs\Python\Python310\Scripts\pip.exe install azure-cli
#C:\Users\Administrator\AppData\Local\Programs\Python\Python310\Scripts\pip.exe install git-bash 

pip.exe install awscli
pip.exe install azure-cli
pip.exe install git-bash
pip.exe install awsprocesscreds
pip.exe install git-remote-codecommit
pip.exe install boto3
pip.exe install pycryptodome


$env:AWS_DEFAULT_PROFILE="core-tools"
$env:AWS_DEFAULT_REGION="us-east-1"
$env:AWS_REGION="us-east-1"
$env:AWS_PROFILE="core-tools"
