﻿# Download & Install AWSCLI v2 

$URL="https://awscli.amazonaws.com/AWSCLIV2.msi"
$path="C:\Users\Administrator\Desktop\Scripts\AWSCLIV2.msi"
Invoke-Webrequest -URI $URL -OutFile $Path
$MYMSI="C:\Users\Administrator\Desktop\Scripts\AWSCLIV2.msi"
$MYARGS="/I $MYMSI /quiet /passive"
Start-Process "msiexec.exe" -ArgumentList $MYARGS -wait -NoNewWindow

Write-Output "AWS program installed !"

#Download & gitbash 

$URL="https://github.com/git-for-windows/git/releases/download/v2.37.3.windows.1/Git-2.37.3-64-bit.exe"
$path="C:\Users\Administrator\Desktop\Scripts\Git-2.37.3-64-bit.exe"
Invoke-Webrequest -URI $URL -OutFile $Path
Start-Process -Wait -ArgumentList "/silent" -PassThru -FilePath $path

Write-Output "Git program installed !"



