﻿# Download & Install Python v2 

$URL="https://www.python.org/ftp/python/3.10.6/python-3.10.6-amd64.exe"
$path="C:\Users\Administrator\Desktop\Scripts\python-3.10.6-amd64.exe"
Invoke-Webrequest -URI $URL -OutFile $Path
Start-Process -FilePath $path  -ArgumentList '/S','/v','qn' -PassThru
