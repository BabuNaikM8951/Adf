﻿# Function to download and install python 3.10.6

function Download_install_python {

$URL="https://www.python.org/ftp/python/3.10.6/python-3.10.6-amd64.exe"
$path="$HOME\Desktop\Scripts\python-3.10.6-amd64.exe"
Invoke-Webrequest -URI $URL -OutFile $Path
Start-Process -FilePath $path -ArgumentList '/S','/v','qn' -PassThru

$ENV:Path += ";$HOME\APPData\Local\Programs\Python\Python310"

[Environment]::SetEnvironmentVariable("PATH", $Env:PATH + ";$HOME\AppData\Local\Programs\Python\Python310", [EnvironmentVariableTarget]::Machine)
[Environment]::SetEnvironmentVariable("PATH", $Env:PATH + ";$HOME\AppData\Local\Programs\Python\Python310\Scripts", [EnvironmentVariableTarget]::Machine)

Write-Output "Python program installed !"
}

function Download_install_AWSCLI {

# Download & Install AWSCLI v2 

$URL="https://awscli.amazonaws.com/AWSCLIV2.msi"
$path="$Home\Desktop\Scripts\AWSCLIV2.msi"
Invoke-Webrequest -URI $URL -OutFile $Path
$MYMSI="$Home\Desktop\Scripts\AWSCLIV2.msi"
$MYARGS="/I $MYMSI /quiet /passive"
Start-Process "msiexec.exe" -ArgumentList $MYARGS -wait -NoNewWindow

Write-Output "AWS program installed   !"

}

function Download_install_AzureCLI {

# Download & Install AzureCLI v2 

$URL="https://azcliprod.blob.core.windows.net/msi/azure-cli-2.41.0.msi"
$path="$Home\Desktop\Scripts\azure-cli-2.41.0.msi"
Invoke-Webrequest -URI $URL -OutFile $Path
$MYMSI="$Home\Desktop\Scripts\azure-cli-2.41.0"
$MYARGS="/I $MYMSI /quiet /passive"
Start-Process "msiexec.exe" -ArgumentList $MYARGS -wait -NoNewWindow

Write-Output "AZURECLI program installed   !"

}


function Download_install_GIT {

#Download & gitbash 

$URL="https://github.com/git-for-windows/git/releases/download/v2.37.3.windows.1/Git-2.37.3-64-bit.exe"
$path="$Home\Desktop\Scripts\Git-2.37.3-64-bit.exe"
Invoke-Webrequest -URI $URL -OutFile $Path
Start-Process -Wait -ArgumentList "/silent" -PassThru -FilePath $path

Write-Output "Git program installed !"
}

# Check for python and install if not already present 
Write-Host "***********************************"
$output_py = "$HOME\APPData\Local\Programs\Python\Python310\python.exe"

if (Test-Path $output_py) {
    Write-Host "Python binary exists - skipping installation"
    }
    
else{
Write-Host "Python binary Does NOT exists - Downloading and Installing "

Download_install_python

}


#Check for AwsCli V2, Downloaded install if already not present 
Write-Host "***********************************"
Write-Host "Checking for AWSVCLI V2"
$output_aws = "C:\Program Files\Amazon\AWSCLIV2\aws.exe"
if (Test-Path $output_aws) {
    Write-Host "Awscli already exists - skipping installation"
    }
    
else{
Write-Host "Awscli Does NOT exists - Downloading and Installing "


Download_install_AWSCLI

}


#Check for AzureCli V2, Downloaded install if already not present 
Write-Host "***********************************"
Write-Host "Checking for AZURECLI V2"
$output_aws = "C:\Program Files\Amazon\Azurecli\azure-cli-2.41.0.exe"
if (Test-Path $output_aws) {
    Write-Host "Azurecli already exists - skipping installation"
    }
    
else{
Write-Host "Azurecli Does NOT exists - Downloading and Installing "

Download_install_AzureCLI

}


#Check for Git, Download install if already not present 
Write-Host "***********************************"
Write-Host "Checking for Git"
$output_git = "C:\Program Files\Git\cmd\git.exe"
if (Test-Path $output_git) {
    Write-Host "Git program already exists - skipping installation"
    }
    
else{
Write-Host "Git program Does NOT exists - Downloading and Installing "

Download_install_GIT

}


