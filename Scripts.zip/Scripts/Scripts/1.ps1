﻿$env:AWS_DEFAULT_PROFILE="core-tools"
$env:AWS_DEFAULT_REGION="us-east-1"
$env:AWS_REGION="us-east-1"
$env:AWS_PROFILE="core-tools"
git clone codecommit::us-east-1://service-ims-package