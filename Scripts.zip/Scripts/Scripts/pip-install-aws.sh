#!/bin/bash

echo "upgrading pip..."
sleep 3

python.exe -m pip install --upgrade pip

echo "Installing aws requirements..."

pip install awsprocesscreds
pip install git-remote-codecommit
pip install boto3
pip install pycryptodome

export AWS_DEFAULT_PROFILE="core-tools"
export AWS_DEFAULT_REGION="us-east-1"
export AWS_REGION="us-east-1"
export AWS_PROFILE="core-tools"