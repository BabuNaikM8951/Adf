﻿

# Function to download and install python 3.10.6

function Down_inst_python {

$URL="https://www.python.org/ftp/python/3.10.6/python-3.10.6-amd64.exe"
$path="$HOME\Desktop\Scripts\python-3.10.6-amd64.exe"
Invoke-Webrequest -URI $URL -OutFile $Path
Start-Process -FilePath $path -ArgumentList '/S','/v','qn' -PassThru

Write-Output "Python program installed !"

#$ENV:Path += ";$HOME\APPData\Local\Programs\Python\Python310"

[Environment]::SetEnvironmentVariable("PATH", $Env:PATH + ";$HOME\AppData\Local\Programs\Python\Python310", [EnvironmentVariableTarget]::Machine)

Write-Output "Python variable is set!"


}


# python binary exe file is taken to output variable 
$output = "$HOME\APPData\Local\Programs\Python\Python310\python.exe"

# testing if the variable exists, and if exists skips the script else it will download and install python using function defined earlier "Down_inst_python"
if (Test-Path $output) {
    Write-Host "Python binary exists - skipping installation"
    }
    
else{
Write-Host "Python binary Does NOT exists - Downloading and Installing "

Down_inst_python
}
